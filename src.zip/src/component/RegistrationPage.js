import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

function RegistrationPage() {
  const [userInfo, setUserInfo] = useState({
    firstName: "",
    lastName: "",
    age: "",
    gender: "",
    skills: [],
    about: "",
  });

  const navigate = useNavigate();

  const handleInputChange = (event) => {
    const target = event.target;
    const name = target.name;
    const value = target.type === "checkbox" ? target.checked : target.value;
    setUserInfo({ ...userInfo, [name]: value });
  };

  const handleSkillsChange = (event) => {
    const selectedSkills = Array.from(
      event.target.selectedOptions,
      (option) => option.value
    );
    setUserInfo({ ...userInfo, skills: selectedSkills });
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    localStorage.setItem("userInfo", JSON.stringify(userInfo));
    navigate("/profile");
  };

  return (
    <div>
      <h1>Registration Page</h1>
      <form onSubmit={handleSubmit}>
        <label>
          First Name:
          <input
            type="text"
            name="firstName"
            value={userInfo.firstName}
            onChange={handleInputChange}
          />
        </label><br/>
        <label>
          Last Name:
          <input
            type="text"
            name="lastName"
            value={userInfo.lastName}
            onChange={handleInputChange}
          />
        </label><br/>
        <label>
          About yourself:
          <textarea
            name="about"
            value={userInfo.about}
            onChange={handleInputChange}
          />
        </label><br/>
        <label>
          Profile pic:
          <input type="file" />
        </label><br/>
        <a href="/login">Already have an account?</a>
        <br />
        <a href="/forgot-password">Forgot password?</a>
        <br />
        <label>
          Age:
          <select name="age" value={userInfo.age} onChange={handleInputChange}>
            <option value="">Select your age</option>
            {Array.from({ length: 18 }, (_, i) => i + 18).map((age) => (
              <option key={age} value={age}>
                {age}
              </option>
            ))}
          </select>
        </label><br/>
        <label>
          Gender:
          <br />
          <label>
            <input
              type="radio"
              name="gender"
              value="male"
              checked={userInfo.gender === "male"}
              onChange={handleInputChange}
            />{" "}
            Male
          </label>
          <br />
          <label>
            <input
              type="radio"
              name="gender"
              value="female"
              checked={userInfo.gender === "female"}
              onChange={handleInputChange}
            />{" "}
            Female
          </label>
        </label><br/>
        <label>
          Skills:
          <br />
          <select
            name="skills"
            multiple={true}
            value={userInfo.skills}
            onChange={handleSkillsChange}
          >
            <option value="react">React</option>
            <option value="java">Java</option>
            <option value="nodejs">NodeJS</option>
            <option value=".net">.Net</option>
          </select>
        </label><br/>
        <label>
          <input type="checkbox" required />
          I agree to the terms and conditions.
        </label>
        <br />
        <button type="submit">Submit</button>
      </form>
      </div>
  );
            }   


export default RegistrationPage;
        