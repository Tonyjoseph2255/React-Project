import React, { useState } from "react";
import { Link } from "react-router-dom";

function ProfilePage() {
  const [userInfo, setUserInfo] = useState(
    JSON.parse(localStorage.getItem("userInfo"))
  );

  return (
    <div>
      <h1>Profile Page</h1>
      <h2>Welcome {userInfo.firstName}!</h2>
      <p><strong>About:</strong> {userInfo.about}</p>
      <p><strong>Age:</strong> {userInfo.age}</p>
      <p><strong>Gender:</strong> {userInfo.gender}</p>
      <p><strong>Skills:</strong> {userInfo.skills.join(", ")}</p>
      <img src={userInfo.profilePic} alt="Profile Pic" />
      <p>
        <Link to="/">Back to Registration Page</Link>
      </p>
    </div>
  );
}

export default ProfilePage;
